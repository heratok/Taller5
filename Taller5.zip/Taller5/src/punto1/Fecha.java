
package punto1;


public class Fecha {
    private String dia;
    private String mes;
    private String año;
   

    public Fecha(String dia, String mes, String año) {
        this.dia = dia;
        this.mes = mes;
        this.año = año;
    }
   

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public String getAño() {
        return año;
    }

    public void setAño(String año) {
        this.año = año;
    }
    
    public void imprimirNacimiento(){
        System.out.println("La fecha de nacimiento es | Mes: "+getMes()+ "| Dia: "+getDia()+"| Año: "+getAño());
    }
 
}
