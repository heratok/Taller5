
package PruebaAsignatura;


import punto7.*;
import java.util.Scanner;
import java.util.Collections;
public class PruebaAsignatura {
    public static void main(String[] args) {
        Asignatura a1=new Asignatura();
        a1.crearGrupos();
        Grupo a11=new Grupo();
        a11.crearGrupos2();
        crearAsignatura();
    }
    public static void crearAsignatura(){
        String nombre_asig,codigo_asig;
        Scanner entrada=new Scanner(System.in);
        System.out.println("----------------------------------------");
        System.out.println("CREE UNA ASIGNATURA");
        System.out.println("nombre de la asignatura: ");
        nombre_asig=entrada.next();
        System.out.println("codigo de la asignatura: ");
        codigo_asig=entrada.next();
        int []num_grupo=new int[3];
        String []docente=new String[3];
        String []nombre= new String[3];
        String []apellidos= new String[3];
        double []notas=new double [3];
        for (int i=0;i<3;i++){
            System.out.println("numero del grupo: "+(i+1));
            num_grupo[i]=entrada.nextInt();
            System.out.println("docente a cargo del grupo: "+(i+1));
            docente[i]=entrada.next();
            for (int j=0;j<3;j++){
                System.out.println("----------------------------------------");
                System.out.println("escriba el primer nombre del estudiante "+(j+1));
                nombre[j]=entrada.next();
                System.out.println("escriba el primer apellido del estudiante "+(j+1));
                apellidos[j]=entrada.next();
                for (int x=0;x<3;x++){
                    System.out.println("escriba la nota del periodo "+(x+1));
                    notas[x]=entrada.nextDouble();
                }
            }
            System.out.println("nombre asignatura: "+nombre_asig);
            System.out.println("codigo asignatura: "+codigo_asig);
            System.out.println("docente a cargo: "+docente);
            System.out.println("primer nombre estudiante: "+nombre);
            System.out.println("primer apellido estudiante: "+apellidos);
            for (int j=0;j<notas.length;j++){
            System.out.println("nota periodo "+(j+1)+": "+notas[j]);
            }
        }  
    }
}
