
package punto7;


public class Grupo {
    private String nombre_asig,nombre_estu,apellido_estu,codigo_asig,docente;
    private int num_grupos;
    private double []notas={3.5,4.5,4.9};
    public Grupo(){
        this.num_grupos=3;
        this.nombre_estu="Hector";
        this.apellido_estu="Rincon";
        this.docente="ANANIAS";
        this.notas=notas;
    }
    public String getNombre_estu() {
        return nombre_estu;
    }

    public void setNombre_estu(String nombre_estu) {
        this.nombre_estu = nombre_estu;
    }

    public String getApellido_estu() {
        return apellido_estu;
    }

    public void setApellido_estu(String apellido_estu) {
        this.apellido_estu = apellido_estu;
    }
    public String getDocente() {
        return docente;
    }
    public void setDocente(String docente) {
        this.docente = docente;
    }
    public void imprimir_notas(){
        for (int i=0;i<notas.length;i++){
            System.out.println("nota periodo "+(i+1)+": "+notas[i]);
        }
    }
    public void crearGrupos2(){
        System.out.println("docente a cargo: "+getDocente());
        System.out.println("primer nombre estudiante: "+getNombre_estu());
        System.out.println("primer apellido estudiante: "+getApellido_estu());
        imprimir_notas();
    } 
}