/*
Escribir una clase en Java llamada Párrafo, con atributo de instancia de tipo String denominado texto, método
constructor por defecto, sobrecargado, getters y setters y los siguientes métodos miembros:
nVocales() : retorna el número de vocales existentes en el texto
nConsonantes(): retorna el número de consonantes en el texto
nSimbolos(): retorna el número de símbolos existentes en el texto
buscar(): retorna el número de repeticiones existentes en el texto de una palabra recibida como parámetro.
vocalModa(): retorna la vocal que más repeticiones presenta en el texto.
nPalabras(): retorna el número de palabras en el párrafo
palabraMayor(): imprime la palabra más larga del texto y su tamaño.
 */
package punto2;

import java.io.Console;
import java.util.Scanner;

public class Parrafo {

    private String texto;
    private String oracion;
    private String palabra;
    private char [] vocales={'a','e','i','o','u'};
    private char [] consonantes={'B','C','D','F','G','H','J','K','L','M','N','Ñ','P','Q','R','S','T','V','X','Z','W','Y'};
    
    //constructor defecto
    public Parrafo() {

    }

    public String gettexto() {
        return this.texto;
    }

    public void settexto(String texto) {
        this.texto = texto;
    }

    public int nVocales() {
        texto=leer();
        int contvocales=0; //contador de vocales
        for (int i = 0; i < texto.length(); i++) { //recorrer el vector vocales que tiene las vocales
            for (int j = 0; j < vocales.length; j++) { //recorrear cada una de las posicones de la variable texto
                if (vocales[j] == Character.toLowerCase(texto.charAt(i))){  
                    contvocales += 1;
                           
                }
                
            }      
        }
        return contvocales;
    }
    public int nConsonantes() {
        texto=leer();
        int contconsonates=0;
        for (int i = 0; i < texto.length(); i++) {
            for (int j = 0; j < consonantes.length; j++) {
                if (Character.toLowerCase(consonantes[j]) == Character.toLowerCase(texto.charAt(i))) {
                    contconsonates += 1;
                    
                }
                
            }
            
        }
        return contconsonates;
    }

    public int buscar(){
        Console cns = System.console();
        int contpalabras=0;
        String textos=cns.readLine(); //invocamos  el metodo leer para obtener la palabra que se almacenara en la variable texto proxima a scanear
        oracion=cns.readLine();
        String[] palabras = oracion.split(" ");
        contpalabras = 0;
        for (int i = 0; i < palabras.length-1; i++) { 
            if (textos.equals(palabras[i]));
            System.out.println(textos+" : "+palabras[i]);
            contpalabras += 1;   
        }
    return contpalabras;
    }
    public int vocalModa(){
        texto=leer();
        int [] moda={0,0,0,0,0};
        for (int i = 0; i < texto.length(); i++) { //recorrer el vector vocales que tiene las vocales
            for (int j = 0; j < vocales.length; j++) { //recorrear cada una de las posicones de la variable texto
                if (vocales[j] == Character.toLowerCase(texto.charAt(i))){  
                    switch(texto.charAt(i)){
                        case 'a':
                            moda[0]+=1;
                            break;
                        case 'e':
                            moda[1]+=1;
                            break;
                        case 'i':
                            moda[2]+=1;
                            break;
                        case 'o':
                            moda[3]+=1;
                            break;
                        case 'u':
                            moda[4]+=1;
                            break;  
                    }
                           
                }
                
            }      
        }
        int mayor=0;
        for (int i = 0; i < 5; i++) {
            System.out.println(moda[i]);
            if (moda[i]<mayor){
                mayor=i;
                
            }  
        }
        return moda[mayor];
        
    }
    public int nPalabras(){
        String [] oraciones =leer().split(" ");
        return oraciones.length;   
    }
    public String palabraMayor(){
        String [] oraciones =leer().split(" ");
        int mayor2=0;
        for (int i = 0; i < oraciones.length; i++) {
            if (oraciones[i].length()>mayor2){
                mayor2=i;
                
            }  
        }
        return oraciones[mayor2];
        
    }
    public String leer(){
        Scanner leer = new Scanner(System.in);
        texto=leer.nextLine();
        return texto;
    }
}
