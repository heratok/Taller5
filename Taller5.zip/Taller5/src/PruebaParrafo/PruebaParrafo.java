package PruebaParrafo;

import punto1.*;
import punto2.Parrafo;
import java.util.Scanner;

public class PruebaParrafo {

    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in);

        Parrafo parrafo = new Parrafo();
        int opciones;
        boolean continuar = true;

        while (continuar == true) {

            System.out.println("ESCOJA UNA OPCION: ");
            System.out.println("1.el número de vocales existentes en el texto: ");
            System.out.println("2.el número de consonantes en el texto: ");
            System.out.println("3.el número de repeticiones existentes en el texto de una palabra recibida como parámetro: ");
            System.out.println("4.la vocal que más repeticiones presenta en el texto: ");
            System.out.println("5.el número de palabras en el párrafo: ");
            System.out.println("6. imprime la palabra más larga del texto y su tamaño: ");
            System.out.println("7.salir ");
            opciones = leer.nextInt();
            if (opciones == 1) {
                System.out.println("por favor ingrese la palabra o texto a verificar: ");
                System.out.println("El texto contiene " + parrafo.nVocales() + " vocales ");
            } else if (opciones == 2) {
                System.out.println("por favor ingrese la palabra o texto a verificar: ");
                System.out.println("El texto contiene " + parrafo.nConsonantes() + " consonantes ");
            } else if (opciones == 3) {
                System.out.println("por favor ingrese la palabra y luego el  texto a  verificar: ");
                System.out.println("El texto contiene " + parrafo.buscar() + " veces repetida la palabra ");   
            } else if (opciones == 4) {
                System.out.println("por favor ingrese la palabra y luego el  texto a  verificar: ");
                System.out.println("La vocal  " + parrafo.vocalModa() + " ");
            } else if (opciones == 5) {
                System.out.println("por favor ingrese la palabra y luego el  texto a  verificar: ");
                System.out.println("El numero de palabras en el parrafo es:   " + parrafo.nPalabras() + " ");  
            } else if (opciones == 6) {
                System.out.println("por favor ingrese la palabra a  verificar: ");
                System.out.println("La palabra mas larga del texto es:  " + parrafo.palabraMayor() + " ");  
            } else if (opciones == 7) {
                continuar = false;
                System.out.println("Gracias por ingresar mi programa ");
            }
        }

    }

}
